# lib-BQ27421
A library based on STM32 CubeMX HAL drivers for interfacing with the Texas Instruments BQ27421 Fuel Gauge IC
